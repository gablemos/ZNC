# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('curriculo', '0010_auto_20161209_1547'),
    ]

    operations = [
        migrations.CreateModel(
            name='Candidato',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nome', models.CharField(max_length=50)),
                ('cpf', models.CharField(max_length=14)),
                ('link_github', models.URLField(max_length=100)),
                ('pretencao_min', models.FloatField()),
                ('pretencao_max', models.FloatField()),
                ('tipo_curriculo', models.CharField(max_length=15)),
                ('telefone', models.CharField(max_length=15)),
                ('email', models.EmailField(max_length=100)),
                ('LP', models.ForeignKey(to='curriculo.LP')),
            ],
        ),
        migrations.AlterField(
            model_name='endereco',
            name='logradouro',
            field=models.CharField(max_length=50),
        ),
        migrations.AlterField(
            model_name='idiomas',
            name='nivel',
            field=models.IntegerField(default=1, choices=[(1, b'Iniciante'), (2, b'Basico'), (3, b'Medio'), (4, b'Avancado'), (5, b'Fluente')]),
        ),
    ]
