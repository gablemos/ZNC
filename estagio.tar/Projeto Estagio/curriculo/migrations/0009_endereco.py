# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('curriculo', '0008_experiencia'),
    ]

    operations = [
        migrations.CreateModel(
            name='Endereco',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('cep', models.CharField(max_length=10)),
                ('logradouro', models.CharField(max_length=25)),
                ('bairro', models.CharField(max_length=25)),
                ('numero', models.CharField(max_length=25)),
                ('complemento', models.TextField()),
                ('cidade', models.CharField(max_length=25)),
                ('estado', models.CharField(max_length=2)),
            ],
        ),
    ]
