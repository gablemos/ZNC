# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('curriculo', '0009_endereco'),
    ]

    operations = [
        migrations.AlterField(
            model_name='idiomas',
            name='descricao',
            field=models.CharField(default=b'EN', max_length=15, choices=[(b'PT', b'Portugues'), (b'EN', b'Ingles'), (b'FR', b'Frances'), (b'ES', b'Espanhol')]),
        ),
        migrations.AlterField(
            model_name='idiomas',
            name='nivel',
            field=models.CharField(default=1, max_length=15, choices=[(1, b'Iniciante'), (2, b'Basico'), (3, b'Medio'), (4, b'Avancado'), (5, b'Fluente')]),
        ),
    ]
