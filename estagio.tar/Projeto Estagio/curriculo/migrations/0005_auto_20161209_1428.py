# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('curriculo', '0004_auto_20161209_1424'),
    ]

    operations = [
        migrations.AlterField(
            model_name='paper',
            name='data_pubicacao',
            field=models.DateField(default='2016-12-09'),
            preserve_default=False,
        ),
    ]
