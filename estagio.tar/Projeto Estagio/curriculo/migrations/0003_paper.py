# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('curriculo', '0002_auto_20161209_1412'),
    ]

    operations = [
        migrations.CreateModel(
            name='paper',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('data_pubicacao', models.DateField()),
                ('titulo', models.CharField(max_length=50)),
                ('link', models.URLField()),
            ],
        ),
    ]
