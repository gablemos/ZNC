from django.contrib import admin
from .models import *

admin.site.register(LP)
admin.site.register(Idiomas)
admin.site.register(Paper)
admin.site.register(Formacao)
admin.site.register(Projeto_op)
admin.site.register(Experiencia)
admin.site.register(Endereco)
admin.site.register(Candidato)
