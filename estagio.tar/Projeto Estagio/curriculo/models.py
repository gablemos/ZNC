from django.db import models


class LP(models.Model):
    descricao = models.CharField(max_length=30)
    ano_exp = models.IntegerField()

    def __str__(self):
        return self.descricao


class Idiomas(models.Model):
    IDIOMAS_NIVEL_CHOICES = (
        (1, 'Iniciante'),
        (2, 'Basico'),
        (3, 'Medio'),
        (4, 'Avancado'),
        (5, 'Fluente')
    )

    descricao = models.CharField(
        max_length=15,)
    nivel = models.IntegerField(
        choices=IDIOMAS_NIVEL_CHOICES,
        default=1)

    def __str__(self):
        return self.descricao


class Paper(models.Model):
    data_pubicacao = models.DateField(
        auto_now=False,
        auto_now_add=False)
    titulo = models.CharField(max_length=50)
    link = models.URLField(max_length=200)


class Formacao(models.Model):
    nivel = models.CharField(max_length=25)
    instituicao = models.CharField(max_length=50)
    curso = models.CharField(max_length=25)
    ano_formacao = models.IntegerField()


class Projeto_op(models.Model):
    nome = models.CharField(max_length=50)
    descricao = models.TextField()
    link = models.URLField(max_length=200)


class Experiencia(models.Model):
    empresa = models.CharField(max_length=50)
    data_inicio = models.DateField(
        auto_now=False,
        auto_now_add=False)
    data_termino = models.DateField(
        auto_now=False,
        auto_now_add=False)
    descricao = models.TextField()


class Endereco(models.Model):
    cep = models.CharField(max_length=10)
    logradouro = models.CharField(max_length=50)
    bairro = models.CharField(max_length=25)
    numero = models.CharField(max_length=25)
    complemento = models.TextField()
    cidade = models.CharField(max_length=25)
    estado = models.CharField(max_length=2)


class Candidato(models.Model):
    TIPO_CURRICULO_CHOICES = (
        (1, 'Estagio Dev'),
        (2, 'Estagio Adm'),
        (3, 'Desenvolvedor'),
        (4, 'Gestor')
    )

    nome = models.CharField(max_length=50)
    cpf = models.CharField(max_length=14)
    link_github = models.URLField(max_length=100)
    pretencao_min = models.FloatField()
    pretencao_max = models.FloatField()
    tipo_curriculo = models.IntegerField(
        choices=TIPO_CURRICULO_CHOICES,
        default=1)
    telefone = models.CharField(max_length=15)
    email = models.EmailField(max_length=100)
    LP = models.ForeignKey(LP)
