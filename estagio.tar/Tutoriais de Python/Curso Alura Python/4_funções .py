from biblioteca import *
from datetime import date

print processa_convite("Gabriel Lemos")

idade = date.today().year - int(raw_input())

print idade