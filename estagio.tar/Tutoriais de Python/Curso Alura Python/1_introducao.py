# coding: UTF-8
nome = 'Gabriel'
idade = 25
print 'Meu nome é ' + nome + 'e tenho ' + str(idade) + ' anos'

x = 5
y = '9'

print x+int(y)

print 'Meu nome é %s e tenho %s' %(nome, idade)



nome = 'nome'
