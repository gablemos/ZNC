
	nome = 'Gabriel'
	pessoas = ['Ana','Carol','Marcela']
	pessoas.append(nome)
	print pessoas

	pessoas.remove(nome)
	print pessoas[1:]

	pessoas = ['Ana','Carol','Marcela']
	pessoa_removida = pessoas.pop(0)
	print pessoa_removida
	print pessoas

