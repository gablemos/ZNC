x = int(raw_input()) + int(raw_input())
print "X =",x