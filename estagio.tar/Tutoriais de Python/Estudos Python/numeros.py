x=1j * 1J
print x
x=1j * complex(0,1)
print x
x= 3+1j*3
print x
x= (3+1j)*3
print x
x= (1+2j)/(1+1j)
print x
x= 1j**2
print x
x= complex(1,1)
print x

print x.conjugate()

print x.imag
print x.real