squares = [1, 4, 9, 16, 25]
print squares[0:]

squares + [36, 49, 64, 81, 100]

print squares