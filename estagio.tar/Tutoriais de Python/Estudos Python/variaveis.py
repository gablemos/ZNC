tax = 12.5 / 100
price = 100.50
price * tax